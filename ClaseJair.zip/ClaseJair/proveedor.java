package ClaseJair;
import java.util.*;

public class proveedor {
    Scanner x=new Scanner (System.in);
    public proveedor() {
    }
    String b,c,e,t,q;
    int a;
    public int idP;
    public String nombre;
    public String direccion;
    public String correo;
    public String telefono;

    public int getIdP() {
      return idP;
    }

    public void setIdP(int idP) {
      this.idP=idP;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre=nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion=direccion;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo=correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono=telefono;
    }
    public void pedirDatos(){
      System.out.println("---------Datos del Proveedor--------------");
      System.out.println("Ingresa su id:");
      int a= x.nextInt();
      System.out.println("Ingresa su nombre:");
      b= x.nextLine();
      b= x.nextLine();
      System.out.println("Ingresa su direccion: ");
      c= x.nextLine();
      System.out.println("Ingresa su email: ");
      e= x.nextLine();
      System.out.println("Ingresa su telefono: ");
      t= x.nextLine();
    }
    public String toString() {
      setIdP(a);setNombre(b);setDireccion(c);setCorreo(e);setTelefono(t);
      return "Id: " + getIdP() + "\n" +"Nombre: " + getNombre() + "\n" +"Direccion:" +getDireccion()+ "\n" +"Email:" +getCorreo()+ "\n" +"Telefono:" +getTelefono();
    }

    public void menu(){
      boolean salir = false;
      int opcion;
      while (!salir) {
          System.out.println("\n Proveedor");
          System.out.println("1. Ingresar Datos");
          System.out.println("2. Ver Datos");
          System.out.println("3. Salir");
          try {
              System.out.println("Escribe una de las opciones:");
              opcion = x.nextInt();

              switch (opcion) {
                  case 1:
                      pedirDatos();
                      break;
                  case 2:
                      q=toString();
                      System.out.println("----------Datos:------------------\n"+q);
                      break;
                  case 3:
                      salir = true;
                      break;
                  default:
                      System.out.println("Solo números entre 1 y 3");
              }
          } catch (InputMismatchException es) {
              System.out.println("Debes insertar un número");
              x.next();
          }
        }
    }
}
