package ClaseJair;
import java.util.*;

public class Producto {
    Scanner x=new Scanner (System.in);
    public Producto() {
    }
    public int id_articulo;
    public String stock;
    public String nombreP;
    public String marca;
    int a;
    String b,c,e;

    public void modificar() {
      System.out.println("---------Vuelve a meter datos--------------");
      System.out.println("Ingresa su id:");
      a= x.nextInt();
      System.out.println("Ingresa el nombre del prodcuto:");
      b= x.nextLine();
      b= x.nextLine();
      System.out.println("Ingresa el stock: ");
      c= x.nextLine();
      System.out.println("Ingresa su marca: ");
      e= x.nextLine();
    }

    public String consultar() {
      setIdArtuculo(a);setStock(b);setNombreP(c);setMarca(e);
      return "Id: " + getIdArticulo() + "\n" +"Stock: " + getStock() + "\n" +"Nombre del Producto:" +getNombreP()+ "\n" +"Marca:" +getMarca();
    }

    public int getIdArticulo() {
        return id_articulo;
    }


    public void setIdArtuculo(int id_articulo) {
        this.id_articulo=id_articulo;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock=stock;
    }

    public void setNombreP(String nombreP) {
        this.nombreP=nombreP;
    }

    public String getNombreP() {
        return nombreP;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca=marca;
    }
    public void Ingresar(){
      System.out.println("---------Datos del Producto--------------");
      System.out.println("Ingresa su id:");
      a= x.nextInt();
      System.out.println("Ingresa el nombre del prodcuto:");
      b= x.nextLine();
      b= x.nextLine();
      System.out.println("Ingresa el stock: ");
      c= x.nextLine();
      System.out.println("Ingresa su marca: ");
      e= x.nextLine();

    }

    public void menu(){
      boolean salir = false;
      int opcion;
      while (!salir) {
          System.out.println("\n Productos");
          System.out.println("1. Ingresar");
          System.out.println("2. Consultar");
          System.out.println("3. Modificar");
          System.out.println("4. Salir");
          try {
              System.out.println("Escribe una de las opciones:");
              opcion = x.nextInt();

              switch (opcion) {
                  case 1:
                      Ingresar();
                      break;
                  case 2:
                      String q=consultar();
                      System.out.println("--------------------Datos:------------------\n"+q);
                      break;
                  case 3:
                      modificar();
                      break;
                  case 4:
                      salir = true;
                      break;
                  default:
                      System.out.println("Solo números entre 1 y 4");
              }
          } catch (InputMismatchException es) {
              System.out.println("Debes insertar un número");
              x.next();
          }
        }
      }

}
