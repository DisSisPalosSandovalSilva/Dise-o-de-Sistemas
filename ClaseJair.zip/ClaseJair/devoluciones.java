package ClaseJair;
import java.util.*;

public class devoluciones extends Peticion {


    public devoluciones() {
    }

    public int idD;
    public int cantidad;
    public String fecha;
    int a,b;
    String f;

    public int getIdD() {
      return idD;
    }

    public void setIdD(int idD) {
        this.idD=idD;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad=cantidad;
    }

    public String getFecha() {
        return fecha;
    }
    public void setFecha(String fecha) {
        this.fecha=fecha;
    }

    public String toString() {
      setIdD(a);setCantidad(b);setFecha(f);
      return "Id: " + getIdD() + "\n" +"Cantidad: " + getCantidad() + "\n" +"Fecha:" +getFecha();
    }
    public void Ingresar(){
      System.out.println("---------Datos de Peticion--------------");
      System.out.println("Ingresa el id:");
      a= x.nextInt();
      System.out.println("Ingresa la cantidad:");
      b= x.nextInt();
      System.out.println("Ingresa el fecha: ");
      f= x.nextLine();
      f= x.nextLine();

    }

    public void menu(){
      boolean salir = false;
      int opcion;
      while (!salir) {
          System.out.println("\n Devolucion");
          System.out.println("1. Ingresar Datos");
          System.out.println("2. Ver Datos");
          System.out.println("3. Salir");
          try {
              System.out.println("Escribe una de las opciones:");
              opcion = x.nextInt();

              switch (opcion) {
                  case 1:
                      Ingresar();
                      break;
                  case 2:
                      String q=toString();
                      System.out.println("---------------Datos:----------------\n"+q);
                      break;
                  case 3:
                      salir = true;
                      break;
                  default:
                      System.out.println("Solo números entre 1 y 3");
              }
          } catch (InputMismatchException es) {
              System.out.println("Debes insertar un número");
              x.next();
          }
        }
    }
}
