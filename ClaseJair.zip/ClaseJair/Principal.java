package ClaseJair;
import java.util.*;
public class Principal{

  public static void main(String [] Args){
      boolean salir = false;
      int opcion;
      Scanner x=new Scanner (System.in);
      proveedor p=new proveedor();
      Producto pr=new Producto();
      ventas v=new ventas();
      Peticion pe=new Peticion();
      while (!salir) {
          System.out.println("\n Opciones");
          System.out.println("1. Proveedor");
          System.out.println("2. Producto");
          System.out.println("3. Ventas");
          System.out.println("4. Peticion");
          System.out.println("5. Salir ");
          try {
              System.out.println("Escribe una de las opciones:");
              opcion = x.nextInt();

              switch (opcion) {
                  case 1:
                      p.menu();
                      break;
                  case 2:
                      pr.menu();
                      break;
                  case 3:
                      v.menu();
                      break;
                  case 4:
                        pe.menu();
                        break;
                  case 5:
                      salir = true;
                      break;
                  default:
                      System.out.println("Solo números entre 1 y 4");
              }
          } catch (InputMismatchException es) {
              System.out.println("Debes insertar un número");
              x.next();
          }
        }
    }
}
