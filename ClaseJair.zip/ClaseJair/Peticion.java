package ClaseJair;
import java.util.*;

public class Peticion {
    Scanner x=new Scanner (System.in);
    public Peticion() {
    }

    public String cliente;
    public String fecha;
    public String producto;
    String a,b,f;

    public String consultar() {
      setCliente(a);setFecha(b);setProducto(f);
      return "Cliente: " + getCliente() + "\n" +"Fecha: " + getFecha() + "\n" +"Producto:" +getProducto();
    }

    public String getCliente() {
        return cliente;
    }
    public void setCliente(String cliente) {
        this.cliente=cliente;
    }
    public String getFecha() {
        return fecha;
    }
    public void setFecha(String fecha) {
      this.fecha=fecha;
    }
    public String getProducto() {
        return producto;
    }
    public void setProducto(String prodcuto) {
      this.producto=prodcuto;
    }
    public void Ingresar(){
      System.out.println("---------Datos de Peticion--------------");
      System.out.println("Ingresa el cliente:");
      a= x.nextLine();
      System.out.println("Ingresa la fecha:");
      b= x.nextLine();
      System.out.println("Ingresa el producto: ");
      f= x.nextLine();
      f= x.nextLine();

    }
    public void menu(){
      boolean salir = false;
      int opcion;
      while (!salir) {
          System.out.println("\n Peticion");
          System.out.println("1. Ingresar Datos");
          System.out.println("2. Ver Datos");
          System.out.println("3. Devolucion");
          System.out.println("4. Salir");
          try {
              System.out.println("Escribe una de las opciones:");
              opcion = x.nextInt();

              switch (opcion) {
                  case 1:
                      Ingresar();
                      break;
                  case 2:
                      String q=consultar();
                      System.out.println("-------------Datos-----------\n"+q);
                      break;
                  case 3:
                      devoluciones d=new devoluciones();
                      d.menu();
                      break;
                  case 4:
                      salir = true;
                      break;
                  default:
                      System.out.println("Solo números entre 1 y 4");
              }
          } catch (InputMismatchException es) {
              System.out.println("Debes insertar un número");
              x.next();
          }
        }
      }
}
