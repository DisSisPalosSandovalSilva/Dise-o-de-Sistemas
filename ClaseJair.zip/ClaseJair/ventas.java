package ClaseJair;
import java.util.*;

public class ventas  {
    Scanner x=new Scanner (System.in);
    public ventas() {
    }
    public int idV;
    public String fecha;
    public int cantidad;
    int a,b;
    String f;
    public int getIdV() {

        return idV;
    }
    public void setIdV(int idV) {
        this.idV=idV;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha=fecha;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad=cantidad;
    }
    public void Ingresar(){
      System.out.println("---------Datos de Ventas--------------");
      System.out.println("Ingresa su id:");
      a= x.nextInt();
      System.out.println("Cantidad:");
      b= x.nextInt();
      System.out.println("Ingresa la fecha: ");
      f= x.nextLine();
      f= x.nextLine();

    }
    public String toString() {
      setIdV(a);setCantidad(b);setFecha(f);
      return "Id: " + getIdV() + "\n" +"Cantidad: " + getCantidad() + "\n" +"Fecha:" +getFecha();
    }

    public void menu(){
      boolean salir = false;
      int opcion;
      while (!salir) {
          System.out.println("\n Ventas");
          System.out.println("1. Ingresar Datos");
          System.out.println("2. Ver Datos");
          System.out.println("3. Salir");
          try {
              System.out.println("Escribe una de las opciones:");
              opcion = x.nextInt();

              switch (opcion) {
                  case 1:
                      Ingresar();
                      break;
                  case 2:
                      String q=toString();
                      System.out.println("---------------Datos:----------------\n"+q);
                      break;
                  case 3:
                      salir = true;
                      break;
                  default:
                      System.out.println("Solo números entre 1 y 3");
              }
          } catch (InputMismatchException es) {
              System.out.println("Debes insertar un número");
              x.next();
          }
        }
      }
}
